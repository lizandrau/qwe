'use strict';

(function() {
	$(document).on("mouseover", ".dacha", function() {
			$('.second').removeClass('header-green');
			$('#gastrobar').removeClass('gastrobar');
			$('.first').removeClass('hidden');
			$('.second').addClass('hidden');
	});
	$(document).on("mouseout", ".dacha", function() {
		$('.second').addClass('header-green');
		$('.first').addClass('hidden');
		$('#gastrobar').addClass('gastrobar');
		$('.second').removeClass('hidden');
})
	$(document).on("mouseover", ".gastrobar", function() {
		$('.second').removeClass('hidden');
	});
	$(document).on("mouseout", ".gastrobar", function() {
		$('.second').addClass('header-green');
	})

	$(document).on("mouseover", ".catering", function() {
		// $('.third').addClass('header-green');
		$('.second').removeClass('header-green');
		$('#gastrobar').removeClass('gastrobar');
		$('.second').addClass('hidden');
		$('.third').removeClass('hidden');
		$('.classes-ru__text').addClass('classes-ru__text--black');
	});
		$(document).on("mouseout", ".catering", function() {
		// $('.third').removeClass('header-green');
		$('.second').addClass('header-green');
		$('#gastrobar').addClass('gastrobar');
		$('.third').addClass('hidden');
		$('.second').removeClass('hidden');
		$('.classes-ru__text').removeClass('classes-ru__text--black');
})


})();